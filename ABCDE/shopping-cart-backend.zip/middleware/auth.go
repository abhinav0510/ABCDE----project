package middleware

import (
    "net/http"
    "shopping-cart/database"
    "shopping-cart/models"

    "github.com/gin-gonic/gin"
)

func AuthMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        token := c.GetHeader("Authorization")
        var user models.User
        database.DB.Where("token = ?", token).First(&user)
        if user.ID == 0 {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
            return
        }
        c.Set("user", user)
        c.Next()
    }
}
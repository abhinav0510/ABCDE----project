package main

import (
    "shopping-cart/controllers"
    "shopping-cart/database"
    "shopping-cart/middleware"
    "shopping-cart/routes"

    "github.com/gin-gonic/gin"
)

func main() {
    database.ConnectDatabase()
    r := gin.Default()

    routes.UserRoutes(r)
    routes.ItemRoutes(r)
    routes.CartRoutes(r)
    routes.OrderRoutes(r)

    r.Run(":8080")
}
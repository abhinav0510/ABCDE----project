package controllers

import (
    "net/http"
    "shopping-cart/database"
    "shopping-cart/models"
    "github.com/gin-gonic/gin"
    "github.com/google/uuid"
)

func CreateUser(c *gin.Context) {
    var input models.User
    if err := c.ShouldBindJSON(&input); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    database.DB.Create(&input)
    c.JSON(http.StatusOK, input)
}

func GetUsers(c *gin.Context) {
    var users []models.User
    database.DB.Find(&users)
    c.JSON(http.StatusOK, users)
}

func LoginUser(c *gin.Context) {
    var input models.User
    if err := c.ShouldBindJSON(&input); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var user models.User
    database.DB.Where("username = ? AND password = ?", input.Username, input.Password).First(&user)
    if user.ID == 0 {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid username/password"})
        return
    }

    token := uuid.New().String()
    database.DB.Model(&user).Update("token", token)
    c.JSON(http.StatusOK, gin.H{"token": token})
}
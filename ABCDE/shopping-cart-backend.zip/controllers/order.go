package controllers

import (
    "net/http"
    "shopping-cart/database"
    "shopping-cart/models"
    "github.com/gin-gonic/gin"
)

func CreateOrder(c *gin.Context) {
    user := c.MustGet("user").(models.User)
    var cart models.Cart
    database.DB.First(&cart, "user_id = ?", user.ID)
    if cart.ID == 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "No cart found"})
        return
    }
    order := models.Order{UserID: user.ID, CartID: cart.ID}
    database.DB.Create(&order)
    c.JSON(http.StatusOK, gin.H{"message": "Order placed", "order_id": order.ID})
}

func GetOrders(c *gin.Context) {
    user := c.MustGet("user").(models.User)
    var orders []models.Order
    database.DB.Where("user_id = ?", user.ID).Find(&orders)
    c.JSON(http.StatusOK, orders)
}
package controllers

import (
    "net/http"
    "shopping-cart/database"
    "shopping-cart/models"
    "github.com/gin-gonic/gin"
)

func AddToCart(c *gin.Context) {
    user := c.MustGet("user").(models.User)
    var input struct {
        ItemID uint `json:"item_id"`
    }
    if err := c.ShouldBindJSON(&input); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var cart models.Cart
    database.DB.FirstOrCreate(&cart, models.Cart{UserID: user.ID})
    cartItem := models.CartItem{CartID: cart.ID, ItemID: input.ItemID}
    database.DB.Create(&cartItem)
    c.JSON(http.StatusOK, gin.H{"message": "Item added to cart"})
}

func GetCarts(c *gin.Context) {
    user := c.MustGet("user").(models.User)
    var cart models.Cart
    database.DB.Preload("Items").First(&cart, "user_id = ?", user.ID)
    c.JSON(http.StatusOK, cart)
}
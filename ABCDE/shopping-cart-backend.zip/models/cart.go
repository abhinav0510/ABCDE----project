package models

type Cart struct {
    ID     uint       `gorm:"primaryKey"`
    UserID uint       `gorm:"unique"`
    Items  []CartItem
}

type CartItem struct {
    ID     uint `gorm:"primaryKey"`
    CartID uint
    ItemID uint
}
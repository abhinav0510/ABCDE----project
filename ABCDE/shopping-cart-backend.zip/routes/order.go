package routes

import (
    "shopping-cart/controllers"
    "shopping-cart/middleware"
    "github.com/gin-gonic/gin"
)

func OrderRoutes(r *gin.Engine) {
    auth := r.Group("/orders")
    auth.Use(middleware.AuthMiddleware())
    {
        auth.POST("/", controllers.CreateOrder)
        auth.GET("/", controllers.GetOrders)
    }
}
package routes

import (
    "shopping-cart/controllers"
    "shopping-cart/middleware"
    "github.com/gin-gonic/gin"
)

func CartRoutes(r *gin.Engine) {
    auth := r.Group("/carts")
    auth.Use(middleware.AuthMiddleware())
    {
        auth.POST("/", controllers.AddToCart)
        auth.GET("/", controllers.GetCarts)
    }
}
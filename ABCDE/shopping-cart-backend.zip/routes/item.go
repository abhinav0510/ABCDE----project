package routes

import (
    "shopping-cart/controllers"
    "github.com/gin-gonic/gin"
)

func ItemRoutes(r *gin.Engine) {
    r.POST("/items", controllers.CreateItem)
    r.GET("/items", controllers.GetItems)
}
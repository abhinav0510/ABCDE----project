package routes

import (
    "shopping-cart/controllers"
    "github.com/gin-gonic/gin"
)

func UserRoutes(r *gin.Engine) {
    r.POST("/users", controllers.CreateUser)
    r.GET("/users", controllers.GetUsers)
    r.POST("/users/login", controllers.LoginUser)
}